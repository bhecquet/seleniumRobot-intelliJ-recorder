SUITE DE NON-REGRESSION SELENIUMROBOT RECORDER

Lancement :
1. Decompresser le ZIP dans un meme dossier.
2. Lancer : python -m http.server 8000
3. Ouvrir : http://localhost:8000/seleniumrobot-non-regression.html

Regle : executer chaque action exactement comme indiquee dans la page.
Chaque cas fournit un identifiant, les actions, le resultat attendu et les resultats interdits.

NEG-001 definit la politique recommandee lorsqu'aucun locator unique fiable n'existe :
- refuser clairement la generation, ou
- produire un fallback positionnel explicitement marque comme fragile.
Ne jamais produire un locator generique non unique.
